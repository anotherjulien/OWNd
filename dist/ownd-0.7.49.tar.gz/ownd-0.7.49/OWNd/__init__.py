""" OWNd - an OpenWebNet daemon """  # pylint: disable=invalid-name
__version__ = "0.7.49"
