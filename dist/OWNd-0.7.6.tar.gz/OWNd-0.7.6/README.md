#OWNd

This package is an event listener and command forwarder for the OpenWebNet protocol.

It is mainly intended to be used in an Home-Assistant integration.

At this point most events are understood.
WHO = 5 (Burglar Alarm) event support is limited and needs further development.
Many commands are implemented, mostly within the requirements of Home-Assistant.